# 08 “最近通话摘要”排障

适用症状：用户输入“总结刚刚电话的主要内容”“给出上一通电话摘要”等请求，Planner 选择了 `history_recent_calls -> call_summarize`，但执行失败。

## 1. 先区分三类失败

### A. 计划引用失败

典型错误：

```text
unresolved plan reference: ${step_1.call_id}
```

检查 `history_recent_calls` 是否把 `call_id` 放在 tool structured result 的顶层稳定字段，而不是只埋在列表项中。

### B. `call_id` 为空或指向不可摘要记录

典型链路：

```text
history_recent_calls -> ok=true, call_id=""
call_summarize("") -> CALL_NOT_FOUND
```

重点检查最近活动是否是 `/text/input` 的 `direct-text` 合成记录、空 transcript 的拨号请求，或当前 actor 无权限访问的通话。

### C. MCP 工具业务失败

HTTP/JSON-RPC 可以成功返回，但 tool result 仍可标记 `isError=true`。当前客户端会继续提取 structured/text content 中的 `error`、`error_code`、`message` 或 `code`。如果只看到泛化错误，先确认是否运行了旧版 `voice_agent/mcp_executor.py`。

## 2. `history_recent_calls.call_id` 的契约

`calls` 用于展示最近活动；顶层 `call_id` 用于计划 handoff。后者必须满足：

- 当前 `actor_terminal_id` 有权访问；
- 有非空 transcript；
- transcript 不是纯 `direct-text` 命令记录；
- 可以直接作为 `call_summarize(call_id=...)` 的输入。

实现会从最近记录向后扫描，不因展示 `limit=1` 就只检查第一条。

## 3. 为什么 active 通话也可以摘要

“刚刚电话”与“latest completed”不是完全相同的业务语义。设备事件可能尚未把状态投影成 completed，但真实 transcript 已经存在。只要权限正确且有真实转写，最近通话查询可以把该通话作为摘要 handoff；这比强依赖状态投影更符合语音链路的最终用户语义。

旧 Repository 若没有 transcript-turn 查询接口，会保留 completed 状态的兼容 fallback，避免破坏旧实现。

## 4. `/text/input` 隔离规则

`direct-text` 用于让文本请求复用 Agent 的 ASR 后续节点，不代表发生了一通电话。因此：

- 保留 `publish_event`，便于审计/trace；
- 跳过 CallStore `project_event`；
- 跳过 `collect_transcript`。

如果状态库中已经存在历史 `direct-text` 合成记录，不需要立即清库；新的 `history_recent_calls` handoff 过滤会跳过它们。

## 5. 推荐排查顺序

1. 查看 Planner capabilities 是否为 `history_recent_calls`, `call_summarize`。
2. 直接调用/单测 `history_recent_calls(actor_terminal_id=<source-id>)`，记录顶层 `call_id`。
3. 查询该 `call_id` 的 transcript turns，确认存在真实 ASR 文本且不是 `direct-text`-only。
4. 用同一 actor 调用 `call_summarize(call_id)`。
5. 若 MCP 返回 `isError=true`，读取透传后的具体错误，而不是只看 HTTP 200。
6. 最后再检查 user delivery；交付成功不代表前面的业务执行成功。

## 6. 回归命令

```bash
python -m pytest -q \
  tests/test_history_recent_calls_reference.py \
  tests/test_plan_reference_mcp_structured_content.py \
  tests/test_direct_text_call_history_isolation.py \
  tests/test_mcp_tool_error_details.py
```

运行中服务：

```bash
python tests/text_input_api_test.py --text 总结刚刚电话的主要内容 --source-id 4
```
