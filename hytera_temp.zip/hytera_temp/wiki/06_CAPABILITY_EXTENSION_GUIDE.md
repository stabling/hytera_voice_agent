# 06 能力扩展指南

## 新增一个设备能力

1. **先定义稳定协议。** 如果终端已有 protobuf tool，保持既有 `tool_id`；新增 tool 必须追加新 ID，不复用旧 ID。
2. **在 `voice_agent/mcp_http_server/tool_defs/*.yaml` 增加 MCP tool 定义。** 工具名、description、input/output schema 是模型和 MCP 客户端的主要契约。
3. **确认 `tool_registry.py` 中存在对应 protobuf request/response class。** 该文件应由生成流程更新，不手改。
4. **CapabilityRegistry 自动把 YAML tool 转为 CapabilitySpec。** 只有 agent-local resolver/reminder 之类能力才在 Registry 内显式定义。
5. **必要时增加 local resolver，而不是让模型猜 ID。** 联系人、区域、信道、通话 ID 都应该由确定性 resolver 解析。
6. **为风险级别添加服务端策略。** 不要把是否允许执行交给 prompt。
7. **补 contract test 和文本 acceptance case。** 新能力应至少有：参数合法、未知参数拒绝、旧工具仍可调用、protobuf 映射稳定。

## 控制大模型上下文的策略

当前 `PLANNER_PROMPT_MODE=compact` 已把模型不需要的 executor/risk/side-effect/domain 元数据从 prompt 中移除，但内部完整契约仍保留。随着工具增加，建议启用下一层分域选择：

- 第一步只给模型 domain 摘要，例如 `sms / zone / call-control / call-content / history / directory / reminder`。
- 第二步只暴露被选 domain 的具体 CapabilitySpec 最小视图。
- 第三步仍由确定性 validator/policy/executor 执行。
- 路由低置信度或跨域请求直接回退 full，确保旧能力不会因为 shortlist 漏选而失效。

这样做比“每个能力单独启动一个 Agent”更适合当前项目：状态、trace、审批、幂等和终端会话仍留在同一条主工作流里，只减少每个模型步骤可见的工具集合。
