# 02 项目架构

![项目架构](../docs/architecture.svg)

## 进程边界

### x64 智能体进程

入口为 `langgraph_agent_x64/run_agent.py` 和 `run_mcp_server.py`。负责 ASR、LangGraph 编排、语义规划、策略/审批、Operation、MCP 服务、上下文、通话内容和用户交付。该层可以持续扩展，但设备副作用必须经过受控执行链。

### x86 ADK 网关进程

入口为 `adk_gateway_x86/run_gateway.py`。`shared_runtime.architecture.require_windows_x86_python310()` 验证 Windows/x86/Python 3.10 后进入 `hytera_adk_gateway`。设备侧逻辑集中在 ADK backend、GatewayService 和终端传输边界。

### 稳定共享边界

- `shared_contracts`：跨进程事件、路由、标识和 trace 契约。
- `shared_runtime`：日志、诊断、事件日志、环境和通用纯函数。
- `mcp_to_proto.py` / `proto_to_mcp.py` / protobuf：MCP 与设备网关之间的二进制协议桥。

## 设备控制链

![控制链](../docs/control_chain.svg)

有设备副作用的请求必须经过：

```text
自然语言
 -> SemanticPlanner / schema validation
 -> policy / approval
 -> OperationRuntime
 -> MCP tool validation
 -> protobuf encode
 -> x86 HTTP gateway
 -> TMP.SendCommand / ADK
```

任何新能力都不应绕过这条链路直接让模型访问设备对象。

## 文本输入与真实通话数据的边界

`POST /text/input` 用于直接注入自然语言命令。为了复用 Agent 管线，它会形成 `direct-text` ASR 结果，但这个结果只属于**命令/审计事件**：

```text
/text/input
 -> direct-text ASR event
 -> publish_event (保留)
 -> CallStore projection (跳过)
 -> transcript collection (跳过)
```

真实通话 ASR 则继续投影到 CallStore，并形成后续 `call_get_transcript`、`call_summarize` 可消费的 transcript turns。

这样可以防止“用户刚输入一句总结命令”本身成为“最近一通电话”。

## 最近通话摘要的数据流

```text
用户：总结刚刚电话的主要内容
 -> Planner
 -> history_recent_calls(actor_terminal_id=<当前终端>)
 -> HistoryQueryService 扫描授权通话
 -> 过滤空转写 / direct-text-only
 -> call_id=<最近可摘要真实通话>
 -> plan reference ${step.call_id}
 -> call_summarize(call_id)
 -> CallContentService
 -> 摘要/离线 fallback
 -> user_delivery
```

`history_recent_calls` 同时返回展示列表 `calls` 和 handoff 标量 `call_id`。二者用途不同：展示列表可以保留更广的最近活动信息；`call_id` 必须满足下游 `call_summarize` 的输入前提。

## MCP 错误边界

MCP HTTP/JSON-RPC 调用成功不代表工具业务执行成功。工具返回 `isError=true` 时，执行器会从 structured content 或文本 content 中提取具体 `error/error_code/message/code`，再写入 Operation/Plan 错误，避免只剩泛化的 `MCP tool returned isError=true`。

## 为什么保留单 Agent

当前 LangGraph 已把模型步骤与确定性步骤拆开。与其为每个能力再创建 Agent，更稳定的方式是保留单 Agent，并通过 CapabilityRegistry、domain scope、schema 和节点 prompt 控制每一步可见能力。
