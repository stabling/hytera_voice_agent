# 08 Simulation Lab：无 MCP/ADK 的 Agent 全链路实验台

## 目标

Simulation Lab 用于在没有真实 MCP Server、ADK Gateway 和对讲机的情况下验证生产 Agent：

`纯文本 -> Planner -> 本地 Resolver -> Policy -> OperationRuntime -> MCP tools/call 请求 -> 模拟成功结果 -> Agent 最终结果`

Simulation 不是第二套业务实现。生产 `tools/*.yaml`、`CapabilityRegistry`、`build_mcp_result()` 和 MCP Result 结构仍是唯一协议事实源。

## 数据边界

日常只修改两类数据：

1. `simulation/config/user_profile.yaml`：用户、通讯录、区域/信道和查询型 MCP 返回值；
2. `simulation/scenarios/*.yaml`：用户输入文本、确定性计划和期望的最终 MCP 参数。

后续新增复杂场景时优先扩展 YAML 中预留的 `organization/history/tasks/incidents/environment/mcp_outputs`，而不是为每个 Tool 新建模拟 Handler。

## MCP 模拟规则

1. 每次调用先经过生产 `build_mcp_result()`，因此最终参数必须满足现有 input schema；
2. 所有 MCP 原子能力默认成功；
3. 查询类结果优先取 `mcp_outputs.<tool>`；
4. 常见设备查询可从高层 `device/radio/directory` 配置生成；
5. 其余结果按生产 output schema 自动生成合法值；
6. 返回使用生产 `mcp_tool_result()`，保留 `content + structuredContent + isError` 结构。

## Planner 模式

- `deterministic`：场景文件固定计划，适合 CI 和定位 Planner 之后的代码；
- `real`：调用当前 Qwen Planner，适合验证真实中文语义，MCP 仍然模拟；
- `auto`：有 `DASHSCOPE_API_KEY` 用 real，否则用 deterministic。

## 核心命令

```bash
python -m simulation --planner deterministic --suite
python -m simulation --planner deterministic --text "呼叫周队"
python -m simulation --planner real --text "切换到公安组"
pytest -q tests/test_simulation.py
```

## 当前 Golden Cases

- 切换到公安组：`radio_resolve_zone_channel -> zone_channel_active_set(channel_id=4)`；
- 呼叫周队：`contact_resolve -> call_start(callee_id=5, call_type=private)`；
- 音量调到10：`audio_volume_set(value=10)`；
- 当前音量是多少：`audio_volume_get`，模拟值来自 `device.volume`；
- 音量调大一点：明确标记 `KNOWN_GAP`，Simulation 不替生产 Agent 实现相对数值计算。

## 扩展原则

未来需要验证任务闭环、多终端、事件、人员组织或失败场景时，先扩充配置和 ResultProvider 接口。除非生产能力契约本身发生变化，否则不要在 simulation 目录内增加重复 Tool Schema。
