# 07 测试与验收

验收分为四层：语法/导入、定向单元回归、仓库全量回归、运行中服务/真实设备。前一层通过不能替代后一层。

## 1. 静态编译

```bash
python -m compileall -q voice_agent hytera_adk_gateway shared_runtime shared_contracts adk_gateway_x86 langgraph_agent_x64 mcp_to_proto.py proto_to_mcp.py tool_registry.py
```

用途：发现语法、future import 和模块级编辑错误。

## 2. “最近通话摘要”定向回归

```bash
python -m pytest -q \
  tests/test_history_recent_calls_reference.py \
  tests/test_plan_reference_mcp_structured_content.py \
  tests/test_direct_text_call_history_isolation.py \
  tests/test_mcp_tool_error_details.py
```

覆盖：

- `history_recent_calls.call_id` 可以稳定供 `${step.call_id}` 引用；
- 展示 limit 很小时仍会向后扫描最近可摘要真实通话；
- 空 transcript 和 `direct-text`-only 记录不会成为摘要 handoff；
- requester 是 caller 或通话仍 active 时，只要授权且已有真实 transcript，也可作为“刚刚电话”摘要目标；
- `/text/input` 不污染 CallStore；
- MCP `isError=true` 保留具体服务端错误。

当前结果：**12 passed**。

## 3. 全量 pytest

```bash
python -m pytest -q
```

当前修改包结果：**14 passed, 1 warning**。

warning 来自 `tests/text_input_api_test.py` 中名为 `TestCase` 且自带 `__init__` 的数据类被 pytest 尝试收集；它是命令行验收脚本的数据结构，不影响实际用例执行。

## 4. MCP 文本验收

```bash
python tests/mcp_text_test.py
```

覆盖区域/信道切换、联系人解析 + 私信、上一通电话摘要、protobuf binary dispatched 语义等。当前验收夹具使用权威目录中的 `区域1 / 消防组`，并按能力契约显式传 `mode=conventional`。

## 5. 复现本次修改前/后行为

上传状态数据的关键前置状态：最新若干记录中存在 `/text/input` 生成的合成活动记录；至少存在一通当前终端可访问且带真实 ASR transcript 的通话。

修改前逻辑：

```text
history_recent_calls -> ok=true, call_id=""
call_summarize(call_id="") -> CALL_NOT_FOUND
MCP client -> MCP tool returned isError=true
```

修改后逻辑：

```text
history_recent_calls -> 跳过 direct-text/空转写 -> 返回真实 call_id
call_summarize(real_call_id) -> ok=true
```

## 6. 运行中 HTTP 服务验收

服务启动后执行：

```bash
python tests/text_input_api_test.py --text 总结刚刚电话的主要内容 --source-id 4
```

验收重点：

- HTTP 200 只是接口层成功，不作为最终业务成功判据；
- `plan.error` 应为空；
- `execution_status` 应为 `SUCCEEDED`；
- `user_delivery.content` 应为摘要内容，而不是执行失败；
- 如失败，应优先看到 `CALL_NOT_FOUND`、`FORBIDDEN` 等具体工具错误，而不是泛化 `isError=true`。

## 7. x86 静态兼容契约

```bash
python tests/gateway_compatibility_test.py
```

用于锁定既有 HTTP 路由、protobuf tool ID 和生成文件哈希。协议生成物不要手工改写。

## 8. x86 真机验收

```bash
python verify_adk_real_actions.py ...
```

必须在 Windows x86 Python 3.10、海能达 ADK 可用、真实终端在线的环境执行。mock、静态测试和离线 MCP 测试均不能替代真机确认。
