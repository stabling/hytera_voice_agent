# Hytera ADK Python Gateway Repo Wiki

本 Wiki 以“先理解边界，再扩展能力，最后验证/排障”的顺序组织。x64 智能体可以持续迭代；Windows x86 ADK 网关、protobuf 生成物和既有 tool ID 属于稳定兼容边界。

## 一、理解系统

- [01 重构与本版变更](01_REFACTOR_SUMMARY.md)：当前代码状态、重要修复、保留边界。
- [02 项目架构](02_ARCHITECTURE.md)：进程边界、控制链、文本输入与通话历史链路。
- [03 模块依赖](03_MODULE_DEPENDENCIES.md)：模块之间谁调用谁。
- [04 逐文件目录](04_FILE_CATALOG.md)：Python 文件职责、公开符号和直接依赖。

## 二、开发与兼容

- [05 x86 网关兼容契约](05_X86_GATEWAY_COMPATIBILITY.md)：不能破坏的路由、tool ID 和 protobuf 生成代码。
- [06 能力扩展指南](06_CAPABILITY_EXTENSION_GUIDE.md)：新增本地/MCP 能力的稳定路径。

## 三、验证与排障

- [07 测试与验收](07_TESTING.md)：静态编译、pytest、MCP 文本验收和真实设备验收。
- [08 “最近通话摘要”排障](08_LAST_CALL_SUMMARY_TROUBLESHOOTING.md)：`history_recent_calls -> call_summarize`、空 `call_id`、`isError=true` 的定位方法。

## 架构图

![项目架构](../docs/architecture.svg)

## 核心原则

1. **x86 ADK 网关只承担设备协议边界。** 新业务优先在 YAML ToolCatalog、CapabilityRegistry、Planner/Operation 和上下文层扩展。
2. **LLM 只做语义选择和参数生成。** schema、权限、风险、审批、幂等、终端路由和 protobuf 编码由确定性代码负责。
3. **命令事件与真实通话数据分离。** `/text/input` 的 `direct-text` 事件可审计，但不能伪装成 CallStore 中的真实通话。
4. **跨步骤引用必须返回稳定标量。** 例如 `history_recent_calls.call_id` 必须代表可直接交给 `call_summarize` 的真实目标，而不是展示列表中的任意第一条。
5. **MCP `isError=true` 要保留具体错误。** 客户端不能把 `CALL_NOT_FOUND` 等服务端诊断压缩成一个泛化字符串。
6. **生成代码视为只读。** `generated/python/*_pb2.py` 和 `tool_registry.py` 通过生成流程维护。
