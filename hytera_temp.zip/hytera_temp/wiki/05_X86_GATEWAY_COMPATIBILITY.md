# 05 x86 ADK 网关兼容契约

`contracts/gateway_compatibility.json` 是本次重构生成的静态基线。任何后续结构优化都应先跑 `python tests/gateway_compatibility_test.py`。

## 固定 HTTP 路由

| Path | Method |
|---|---|
| `/adk/protobuf/result-sms` | `POST` |
| `/channels` | `GET` |
| `/health` | `GET` |
| `/sms/group` | `POST` |
| `/sms/private` | `POST` |
| `/voice/callback/dead-letters` | `GET` |
| `/voice/callback/outbox` | `GET` |
| `/voice/capture/start` | `POST` |
| `/voice/capture/stop` | `POST` |
| `/voice/info` | `POST` |
| `/voice/private/send-wav` | `POST` |

## 固定 protobuf tool ID

tool ID 一旦被终端协议使用，就不能因代码排序、YAML 文件顺序或重构而重新编号。当前 54 个映射已完整写入 contract JSON。

## 生成代码保护

以下内容使用 SHA-256 保护：`generated/python/*_pb2.py` 与 `tool_registry.py`。本次重构没有修改它们。若协议确需升级，应通过 protoc/注册表生成流程整体更新，并同步真实 x86 设备验收，而不是手改。

## 真实设备边界

静态 contract test 只能证明 Python 侧没有改路由和生成协议文件，不能证明海能达 ADK/终端真实动作成功。最终发布前仍应在 Windows x86 Python 3.10 环境运行 `verify_adk_real_actions.py`。
