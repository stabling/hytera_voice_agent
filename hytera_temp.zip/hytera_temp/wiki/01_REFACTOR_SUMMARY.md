# 01 重构与本版变更

## 当前稳定边界

- x64 智能体负责 ASR、语义规划、策略/审批、Operation、MCP、上下文和通话内容能力。
- Windows x86 进程负责海能达 ADK、终端投递和既有 HTTP/Protobuf 协议。
- `generated/python/*_pb2.py` 与 `tool_registry.py` 属于生成/协议产物，不做手工业务重构。
- 新能力优先通过 Tool YAML、CapabilityRegistry、本地能力执行器或 MCP 服务层增加，不绕过 Operation/MCP/Protobuf 控制链。

## 本版：修复“总结刚刚电话”执行失败

### 故障表现

计划可以正确生成：

```text
history_recent_calls -> call_summarize
```

但执行阶段出现：

```text
MCP tool returned isError=true
```

### 根因

上传状态库中，`history_recent_calls` 的展示结果会命中由 `/text/input` 产生的 `direct-text` 合成会话。这些记录没有真实可摘要的通话转写，旧实现仍可能返回 `ok=true` 且 `call_id=""`。计划引用随后把空字符串交给 `call_summarize`，服务端实际返回 `CALL_NOT_FOUND`；旧 MCP 客户端又把具体错误折叠成了统一的 `MCP tool returned isError=true`。

### 修复

- `voice_agent/agent/nodes.py`：`/text/input` 的 `direct-text` ASR 事件继续进入审计事件流，但不再投影到 CallStore，也不再收集为通话 transcript。
- `voice_agent/context/repository.py`：为上下文查询边界增加按 `call_id` 获取 transcript turns 的只读接口。
- `voice_agent/context/history.py`：`history_recent_calls.call_id` 从权限范围内按时间扫描“存在真实 ASR 转写”的可摘要通话；跳过空转写和 `direct-text`-only 记录；不再把“必须 completed / 必须 requester 是 callee”当成唯一可用条件。
- `voice_agent/mcp_executor.py`：MCP `isError=true` 时优先透传 `structuredContent.error/error_code/message/code` 或文本结果中的具体错误。
- `voice_agent/mcp_http_server/tool_defs/history.yaml`：同步模型可见契约，明确 `call_id` 是后续 `call_summarize` 可直接消费的最近可摘要目标。
- 增加定向回归，覆盖跨步骤引用、空/合成通话过滤、直接文本隔离和 MCP 错误透传。

## 修改前 / 修改后验证

使用上传包的状态数据验证同一逻辑链：

- 修改前：`history_recent_calls.call_id == ""`；继续调用 `call_summarize("")` 得到 `CALL_NOT_FOUND`。
- 修改后：会跳过当前 `direct-text` 合成记录，选择最近一个带真实 ASR transcript 的授权通话；`call_summarize` 可完成摘要。离线环境中外部摘要模型不可达时，现有 fallback 摘要仍可返回成功结果。

自动化回归：`python -m pytest -q` -> **14 passed**。

## 同步修正的旧验收夹具

`tests/mcp_text_test.py` 原先使用已经不在当前 `voice_zone_channel_map.json` 权威目录中的 `D2`，且 `radio_resolve_zone_channel` 当前契约要求显式 `mode`。验收夹具已同步为当前目录中的 `消防组`，并使用用户未指定模式时的 `conventional`，不改变生产切台实现。

## 既有重构保留项

- `shared_runtime/json_utils.py` 收敛 planning / operations / approvals / memory repository 的稳定 JSON 序列化逻辑。
- `voice_agent/http_api.py` 使用显式依赖，减少 `runtime` 星号导入造成的隐式耦合。
- `CapabilitySpec` 区分完整服务端契约与模型最小契约；Planner 支持 compact/full 能力视图。
- `CapabilityRegistry.domain_index()` 为按领域缩小模型可见能力范围保留接口。
- `tests/gateway_compatibility_test.py` 固化 HTTP 路由、tool ID 和生成文件哈希的静态兼容验证。

## 后续扩展建议

1. 保持“展示列表”和“供计划引用的标量 handoff”语义分离，所有跨步骤引用都增加 consumer-contract 测试。
2. 为每个 YAML tool 增加 schema -> MCP -> executor 的契约测试，避免目录/枚举变化后验收夹具失效。
3. 真实 x86 设备验收单独进入 hardware acceptance 流程；不要把 mock/静态通过等同于 ADK 真机通过。
