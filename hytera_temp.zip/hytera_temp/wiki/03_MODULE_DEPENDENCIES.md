# 03 模块依赖

下表来自 Python AST 静态分析，只统计仓库内直接 import；运行时动态导入（例如 CLR/protobuf）会在对应文件说明中单独体现。

## 被依赖最多的模块

| 模块 | 被多少本地模块直接导入 | 说明 |
|---|---:|---|
| `shared_contracts.models` | 25 | 定义 x86 网关、x64 智能体和 MCP 共享的数据模型、路由、标识符、安全与事件契约；应保持向后兼容。 |
| `voice_agent` | 14 | 负责 ASR、规划、MCP 调用、设备投递、目录解析、HTTP 回调和运行时装配。 |
| `shared_contracts.event_models` | 13 | 定义 x86 网关、x64 智能体和 MCP 共享的数据模型、路由、标识符、安全与事件契约；应保持向后兼容。 |
| `shared_runtime.logging_config` | 12 | 提供日志、可观测性、事件日志、环境加载、架构检查和无业务倾向的通用工具。 |
| `shared_contracts.identifiers` | 12 | 定义 x86 网关、x64 智能体和 MCP 共享的数据模型、路由、标识符、安全与事件契约；应保持向后兼容。 |
| `voice_agent.calls.models` | 11 | 负责通话关联、生命周期、转写、摘要、翻译、查询和通话内容能力。 |
| `shared_contracts.trace_context` | 10 | 定义 x86 网关、x64 智能体和 MCP 共享的数据模型、路由、标识符、安全与事件契约；应保持向后兼容。 |
| `voice_agent.calls.repository` | 10 | 负责通话关联、生命周期、转写、摘要、翻译、查询和通话内容能力。 |
| `shared_runtime.observability` | 9 | 提供日志、可观测性、事件日志、环境加载、架构检查和无业务倾向的通用工具。 |
| `hytera_adk_gateway.models` | 9 | 实现 32 位 Windows/Python 3.10 侧的海能达 ADK HTTP 网关。对外行为必须优先兼容现网和真实终端。 |
| `hytera_adk_gateway.adk.shared` | 9 | 封装海能达 ADK/CLR 交互、通道、消息、事件和语音底层能力。该层属于设备协议边界，重构只能做兼容性增强，不应改变既有 ADK 调用语义。 |
| `voice_agent.storage.interfaces` | 9 | 定义存储接口、SQLite/PostgreSQL 切换、归档、对象存储、保留期和读路径灰度。 |
| `shared_runtime.diagnostics` | 8 | 提供日志、可观测性、事件日志、环境加载、架构检查和无业务倾向的通用工具。 |
| `shared_contracts.routes` | 8 | 定义 x86 网关、x64 智能体和 MCP 共享的数据模型、路由、标识符、安全与事件契约；应保持向后兼容。 |
| `hytera_adk_gateway.capture.io_utils` | 8 | 负责 TShark 抓包、RTP/UDP 数据整理、会话产物和抓包状态管理。 |
| `voice_agent.planning.models` | 8 | 负责计划模型、校验、持久化、策略衔接、等待条件和计划执行前治理。 |
| `voice_agent.storage.runtime` | 8 | 定义存储接口、SQLite/PostgreSQL 切换、归档、对象存储、保留期和读路径灰度。 |
| `voice_agent.operations.models` | 8 | 负责把计划步骤固化为可审计、可幂等、可重试的原子操作并记录执行结果。 |
| `shared_runtime.architecture` | 7 | 提供日志、可观测性、事件日志、环境加载、架构检查和无业务倾向的通用工具。 |
| `hytera_adk_gateway.config` | 7 | 实现 32 位 Windows/Python 3.10 侧的海能达 ADK HTTP 网关。对外行为必须优先兼容现网和真实终端。 |
| `shared_contracts.security` | 7 | 定义 x86 网关、x64 智能体和 MCP 共享的数据模型、路由、标识符、安全与事件契约；应保持向后兼容。 |
| `voice_agent.capabilities` | 7 | 把 MCP 工具和本地能力转换为稳定 CapabilitySpec，供规划、策略和执行共同使用，是后续扩展能力时的重要兼容边界。 |
| `voice_agent.mcp_http_server.tool_catalog` | 6 | 负责 MCP 工具目录、JSON-RPC 适配、参数校验、设备执行和 HTTP Server；工具 YAML 是模型可见 schema 的主要来源。 |
| `voice_agent.contact_directory` | 6 | 负责 ASR、规划、MCP 调用、设备投递、目录解析、HTTP 回调和运行时装配。 |
| `voice_agent.zone_channel_directory` | 6 | 负责 ASR、规划、MCP 调用、设备投递、目录解析、HTTP 回调和运行时装配。 |
| `voice_agent.utils` | 6 | 负责 ASR、规划、MCP 调用、设备投递、目录解析、HTTP 回调和运行时装配。 |
| `hytera_adk_gateway.services` | 5 | 承接 HTTP 路由并协调 ADK backend，保持协议转换、设备调用与 API 层解耦。 |
| `hytera_adk_gateway.callbacks.models` | 5 | 负责回调接收、合并、重试、熔断、Outbox 和投递状态，避免网络波动影响 ADK 主链路。 |
| `shared_contracts.event_types` | 5 | 定义 x86 网关、x64 智能体和 MCP 共享的数据模型、路由、标识符、安全与事件契约；应保持向后兼容。 |
| `voice_agent.mcp_http_server.tool_service` | 5 | 负责 MCP 工具目录、JSON-RPC 适配、参数校验、设备执行和 HTTP Server；工具 YAML 是模型可见 schema 的主要来源。 |

## 依赖最多的模块

| 模块 | 直接本地依赖数 | 主要依赖 |
|---|---:|---|
| `voice_agent.runtime` | 41 | `shared_contracts.event_models`, `shared_contracts.event_types`, `shared_contracts.identifiers`, `shared_contracts.models`, `shared_contracts.trace_context`, `shared_contracts.routes`, `shared_contracts.security`, `shared_runtime.architecture` |
| `voice_agent.planning.runtime` | 12 | `voice_agent.approvals`, `voice_agent.capabilities`, `voice_agent.operations.models`, `voice_agent.operations.runtime`, `voice_agent.policy`, `voice_agent.reasoning`, `voice_agent.planning.executor`, `voice_agent.planning.models` |
| `tests.mcp_text_test` | 11 | `voice_agent.capabilities`, `voice_agent.contact_directory`, `voice_agent.mcp_http_server.device_executor`, `voice_agent.mcp_http_server.protocol_adapter`, `voice_agent.mcp_http_server.tool_catalog`, `voice_agent.mcp_http_server.tool_service`, `voice_agent.mcp_result`, `voice_agent.operations.runtime` |
| `voice_agent.agent.nodes` | 10 | `shared_contracts.event_models`, `shared_contracts.event_types`, `shared_contracts.identifiers`, `shared_runtime.diagnostics`, `voice_agent`, `voice_agent.agent.dependencies`, `voice_agent.agent.framework`, `voice_agent.agent.logging_fields` |
| `voice_agent.context.runtime` | 10 | `voice_agent`, `voice_agent.calls.repository`, `voice_agent.commands.repository`, `voice_agent.memory.repository`, `voice_agent.memory.verifier`, `voice_agent.operations.repository`, `shared_runtime.event_journal`, `voice_agent.context.builder` |
| `hytera_adk_gateway.callbacks.lifecycle` | 9 | `hytera_adk_gateway.capture`, `hytera_adk_gateway.capture.io_utils`, `shared_contracts.event_models`, `shared_contracts.event_types`, `shared_contracts.models`, `hytera_adk_gateway.callbacks.circuit_breaker`, `hytera_adk_gateway.callbacks.models`, `hytera_adk_gateway.callbacks.outbox` |
| `voice_agent.mcp_executor` | 9 | `shared_contracts.identifiers`, `shared_contracts.security`, `shared_contracts.trace_context`, `shared_runtime.observability`, `shared_runtime.diagnostics`, `shared_runtime.logging_config`, `voice_agent`, `voice_agent.mcp_result` |
| `voice_agent.mcp_http_server.execution` | 9 | `shared_contracts.event_models`, `shared_contracts.event_types`, `shared_contracts.identifiers`, `shared_contracts.models`, `shared_contracts.trace_context`, `voice_agent.calls.runtime`, `voice_agent.context.event_publisher`, `voice_agent.mcp_http_server` |
| `voice_agent.storage.postgres.repositories` | 9 | `voice_agent.calls.models`, `voice_agent.memory.models`, `voice_agent.operations.models`, `voice_agent.commands.models`, `voice_agent.context.models`, `voice_agent.context.redaction`, `voice_agent.storage.canonical`, `voice_agent.storage.interfaces` |
| `voice_agent.mcp_http_server.tool_service` | 8 | `voice_agent`, `voice_agent.calls.content_service`, `voice_agent.calls.derived_repository`, `voice_agent.calls.repository`, `voice_agent.calls.resolver`, `voice_agent.context.runtime`, `voice_agent.mcp_http_server.device_executor`, `voice_agent.mcp_http_server.tool_catalog` |
| `voice_agent.server` | 8 | `voice_agent`, `voice_agent.contact_directory`, `voice_agent.http_api`, `voice_agent.logging_utils`, `voice_agent.runtime`, `voice_agent.slots`, `voice_agent.utils`, `voice_agent.zone_channel_directory` |
| `voice_agent.terminal_delivery` | 8 | `mcp_to_proto`, `shared_contracts.routes`, `shared_contracts.security`, `shared_contracts.trace_context`, `shared_runtime.observability`, `shared_runtime.diagnostics`, `voice_agent.utils`, `shared_runtime.logging_config` |
| `hytera_adk_gateway.adk.backend` | 7 | `hytera_adk_gateway.adk.channels`, `hytera_adk_gateway.adk.events`, `hytera_adk_gateway.adk.lifecycle`, `hytera_adk_gateway.adk.messaging`, `hytera_adk_gateway.adk.reflection`, `hytera_adk_gateway.adk.runtime`, `hytera_adk_gateway.adk.voice` |
| `hytera_adk_gateway.api.app` | 7 | `hytera_adk_gateway.api.dependencies`, `hytera_adk_gateway.api.routers.protobuf_tools`, `hytera_adk_gateway.api.routers.sms`, `hytera_adk_gateway.api.routers.system`, `hytera_adk_gateway.api.routers.voice`, `hytera_adk_gateway.api.security`, `hytera_adk_gateway.api.runtime` |
| `voice_agent.agent.workflow` | 7 | `voice_agent.agent.checkpointing`, `voice_agent.agent.dependencies`, `voice_agent.agent.framework`, `voice_agent.agent.nodes`, `voice_agent.agent.runtime_dependencies`, `voice_agent.agent.state`, `voice_agent` |
| `voice_agent.mcp_http_server.device_executor` | 7 | `shared_contracts.security`, `shared_contracts.trace_context`, `shared_runtime.observability`, `shared_runtime.diagnostics`, `voice_agent.mcp_http_server`, `voice_agent.mcp_http_server.execution_context`, `voice_agent.mcp_http_server.tool_catalog` |
| `voice_agent.mcp_http_server.server` | 7 | `shared_contracts.trace_context`, `shared_runtime.observability`, `voice_agent.mcp_http_server`, `voice_agent.mcp_http_server.execution`, `voice_agent.mcp_http_server.execution_context`, `voice_agent.mcp_http_server.protocol_adapter`, `voice_agent.mcp_http_server.tool_service` |
| `hytera_adk_gateway.callbacks.transport` | 6 | `shared_contracts.http_client`, `shared_contracts.security`, `shared_contracts.trace_context`, `shared_runtime.observability`, `hytera_adk_gateway.capture.io_utils`, `hytera_adk_gateway.callbacks.models` |
| `hytera_adk_gateway.services.gateway_service` | 6 | `shared_runtime.diagnostics`, `hytera_adk_gateway.backend`, `hytera_adk_gateway.config`, `hytera_adk_gateway.models`, `hytera_adk_gateway.adk.events`, `shared_runtime.event_publisher` |
| `voice_agent.calls.content_service` | 6 | `shared_contracts.models`, `voice_agent.calls.derived_repository`, `voice_agent.calls.models`, `voice_agent.calls.repository`, `voice_agent.calls.resolver`, `voice_agent.calls.summary_generator` |
| `voice_agent.calls.lifecycle_tracker` | 6 | `shared_contracts.event_models`, `shared_contracts.identifiers`, `shared_contracts.models`, `voice_agent.calls.correlator`, `voice_agent.calls.models`, `voice_agent.calls.repository` |
| `voice_agent.calls.runtime` | 6 | `shared_contracts.event_models`, `voice_agent.calls.correlator`, `voice_agent.calls.lifecycle_tracker`, `voice_agent.calls.models`, `voice_agent.calls.repository`, `voice_agent.calls.transcript_collector` |
| `voice_agent.operations.runtime` | 6 | `shared_contracts.trace_context`, `voice_agent.commands.models`, `voice_agent.commands.repository`, `voice_agent.operations.executor`, `voice_agent.operations.models`, `voice_agent.operations.repository` |
| `hytera_adk_gateway.adk.lifecycle` | 5 | `hytera_adk_gateway.audio`, `hytera_adk_gateway.config`, `hytera_adk_gateway.models`, `hytera_adk_gateway.transport`, `hytera_adk_gateway.adk.shared` |
| `hytera_adk_gateway.callbacks.manager` | 5 | `hytera_adk_gateway.callbacks.lifecycle`, `hytera_adk_gateway.callbacks.merger`, `hytera_adk_gateway.callbacks.payload`, `hytera_adk_gateway.callbacks.source`, `hytera_adk_gateway.callbacks.transport` |
| `voice_agent.approvals.service` | 5 | `voice_agent.planning.models`, `voice_agent.planning.validator`, `voice_agent.policy.engine`, `voice_agent.approvals.models`, `voice_agent.approvals.repository` |
| `voice_agent.memory` | 5 | `voice_agent.memory.extractor`, `voice_agent.memory.models`, `voice_agent.memory.repository`, `voice_agent.memory.retriever`, `voice_agent.memory.verifier` |
| `voice_agent.operations.repository` | 5 | `shared_contracts.models`, `voice_agent.storage.runtime`, `shared_runtime.json_utils`, `voice_agent.operations.models`, `voice_agent.operations.schema` |
| `voice_agent.reminder_scheduler` | 5 | `voice_agent.logging_utils`, `voice_agent.terminal_delivery`, `voice_agent.mcp_result`, `voice_agent.request_ids`, `voice_agent.operations.models` |
| `adk_gateway_x86.run_gateway` | 4 | `shared_runtime.architecture`, `shared_runtime.env_file`, `shared_runtime.logging_config`, `shared_runtime.observability` |

## 核心链路关系

- `voice_agent.runtime` 是当前最大的装配中心，直接依赖多个领域 runtime；后续若继续拆分，应先引入容器对象，再保留模块级兼容别名。
- `voice_agent.agent.nodes` 只通过 `VoiceAgentDependencies` 获取执行能力，这一点应保留，它是 LangGraph 与业务实现之间的重要隔离。
- `voice_agent.capabilities.registry` 依赖 MCP ToolCatalog，但 planning/policy/execution 依赖 CapabilitySpec，而不是直接依赖 YAML。
- `mcp_to_proto.py` 和 `proto_to_mcp.py` 是协议桥，不应被业务层复制实现。
- `hytera_adk_gateway.api` → `services` → `adk` 是 x86 网关的单向主链，避免路由层直接接触 CLR 对象。
