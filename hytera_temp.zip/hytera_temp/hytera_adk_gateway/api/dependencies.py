# =============================================================================
# 【维护注释】文件：hytera_adk_gateway/api/dependencies.py
# 所属层次：x86 网关 API 装配层
# 主要职责：负责 FastAPI 应用工厂、依赖注入、安全中间件、请求/响应模型和生命周期装配。
# 项目内直接依赖：..services
# 主要公开符号：get_service
# 兼容性：不得改变既有外部 HTTP 路径、protobuf 字段/工具 ID、ADK 调用含义或公开 Python 导入路径。
# 修改原则：业务校验留在服务端；模型只做语义选择/填参；跨层通信使用明确契约，避免隐式全局状态。
# 排障顺序：先看输入契约与日志，再看本层返回值，最后沿项目内直接依赖追踪到下游；不要跨层临时绕过校验。
# =============================================================================
from __future__ import annotations

from fastapi import FastAPI, HTTPException

from ..services import GatewayService


def get_service(app: FastAPI) -> GatewayService:
    """从应用状态取得长生命周期网关服务。"""
    service = getattr(app.state, "gateway_service", None)
    if service is None:
        raise HTTPException(status_code=503, detail="网关服务尚未启动")
    return service
