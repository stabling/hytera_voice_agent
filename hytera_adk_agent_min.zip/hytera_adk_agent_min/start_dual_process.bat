@echo off
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0"

set "ADK_PY=%CD%\.venv-adk32\Scripts\python.exe"
set "AGENT_PY=%CD%\.venv-agent64\Scripts\python.exe"

if not exist "%ADK_PY%" (
  echo ERROR: .venv-adk32 is missing. Run adk_gateway_x86\setup.bat first.
  exit /b 1
)
if not exist "%AGENT_PY%" (
  echo ERROR: .venv-agent64 is missing. Run langgraph_agent_x64\setup.bat first.
  exit /b 1
)
if not exist ".env.gateway" copy /y ".env.gateway.example" ".env.gateway" >nul
if not exist ".env.agent" copy /y ".env.agent.example" ".env.agent" >nul

call :check_health "http://127.0.0.1:18083/health"
if errorlevel 1 start "Hytera MCP x64" /D "%CD%" "%AGENT_PY%" -m langgraph_agent_x64.run_mcp_server
call :wait_health "http://127.0.0.1:18083/health" 30
if errorlevel 1 exit /b 1

call :check_health "http://127.0.0.1:18082/health"
if errorlevel 1 start "Hytera LangGraph Agent x64" /D "%CD%" "%AGENT_PY%" -m langgraph_agent_x64.run_agent
call :wait_health "http://127.0.0.1:18082/health" 30
if errorlevel 1 exit /b 1

call :check_health "http://127.0.0.1:18081/health"
if errorlevel 1 start "Hytera ADK Gateway x86" /D "%CD%" "%ADK_PY%" -m adk_gateway_x86.run_gateway --config config\gateway.ini --host 127.0.0.1 --port 18081
call :wait_health "http://127.0.0.1:18081/health" 30
if errorlevel 1 exit /b 1

echo.
echo Dual-process system is running:
echo   ADK Gateway x86:     http://127.0.0.1:18081/health
echo   LangGraph Agent x64: http://127.0.0.1:18082/health
echo   MCP Server x64:      http://127.0.0.1:18083/health
exit /b 0

:check_health
powershell.exe -NoProfile -NonInteractive -ExecutionPolicy Bypass -Command ^
  "$ErrorActionPreference='Stop'; try {$r=Invoke-WebRequest -UseBasicParsing -Uri '%~1' -TimeoutSec 1; if($r.StatusCode -ge 200 -and $r.StatusCode -lt 300){exit 0}} catch {}; exit 1" >nul 2>&1
exit /b %ERRORLEVEL%

:wait_health
powershell.exe -NoProfile -NonInteractive -ExecutionPolicy Bypass -Command ^
  "$deadline=(Get-Date).AddSeconds(%~2); while((Get-Date)-lt $deadline){try{$r=Invoke-WebRequest -UseBasicParsing -Uri '%~1' -TimeoutSec 1;if($r.StatusCode -ge 200 -and $r.StatusCode -lt 300){exit 0}}catch{};Start-Sleep -Milliseconds 300};exit 1" >nul 2>&1
if errorlevel 1 echo ERROR: Service did not become healthy: %~1
exit /b %ERRORLEVEL%
