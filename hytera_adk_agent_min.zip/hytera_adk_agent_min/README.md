# Hytera ADK Agent

本工程由两个运行时边界组成：64 位 Voice Agent/MCP 服务负责自然语言规划、策略、审计和工具契约；Windows x86/Python 3.10 Gateway 负责海能达 ADK 与终端协议。两侧通过稳定的 MCP/protobuf/tool-id 契约连接。

## 当前稳定基线

- Capability：66 个，默认全部可用；唯一默认契约源为 `voice_agent/mcp_http_server/tools/*.yaml`。
- 设备 wire tool：53 个，ID 1~53 保持冻结。
- 文本输入：`direct-text -> LangGraph -> SemanticPlanner -> Policy -> OperationRuntime -> MCP 输入`。
- 本版验证边界：不启动 MCP Server、不启动 ADK Gateway；测试在最终 MCP tool name + arguments 处截断。
- Context Builder：`shadow` 只记录/观测，不进入 Planner；只有 `active` 才影响规划。
- Qwen Context Cache：继续使用固定 system 前缀 + `cache_control={"type":"ephemeral"}` + 动态 user 后缀，不改变命中方式。

## 快速验证

```bash
python -m compileall -q \
  voice_agent shared_runtime shared_contracts mcp_wire generated \
  hytera_adk_gateway adk_gateway_x86 langgraph_agent_x64 \
  mcp_to_proto.py proto_to_mcp.py

python -m pytest -q
```

默认测试不产生外部网络请求。发布前如需验证真实 Qwen 语义选择：

```bash
RUN_LIVE_PLANNER_TESTS=1 python -m pytest -q tests/test_agent_regressions.py -k live_planner
```

该命令需要部署环境提供 `DASHSCOPE_API_KEY`。

## 维护边界

1. 不手工修改 `generated/python/*_pb2.py`、`mcp_wire/tool_registry.py`、`mcp_to_proto.py`、`proto_to_mcp.py`。
2. 新增设备/本地原子能力只修改 `tools/*.yaml` 并走生成/验证流程，不恢复历史 `tool_defs/` 双目录。
3. LLM 只做语义选择和填参；ID 解析、Schema、风险、审批、幂等、下行路由必须由确定性代码处理。
4. 新的 Composite Workflow 应复用 `OperationPlan / OperationRuntime / WaitCondition / DomainEvent`，不要绕过 MCP/Policy 直接控制设备。
5. 每个线上缺陷只向现有回归测试文件补 Case，不再新建一次性调试脚本。

更详细说明见 `wiki/`。
