# =============================================================================
# 【维护注释】文件：agent_server/session/context/__init__.py
# 所属层次：决策上下文层
# 主要职责：负责事件、历史、终端状态等上下文的构建、裁剪、脱敏和快照，为规划器提供受控信息。
# 项目内直接依赖：.builder, .history, .models, .repository
# 主要公开符号：无；以导入副作用、常量、数据模型或包导出为主
# 兼容性：优先通过新增可选接口、适配器或配置开关扩展；旧公开函数/类和已有调用链应继续可用。
# 修改原则：业务校验留在服务端；模型只做语义选择/填参；跨层通信使用明确契约，避免隐式全局状态。
# 排障顺序：先看输入契约与日志，再看本层返回值，最后沿项目内直接依赖追踪到下游；不要跨层临时绕过校验。
# =============================================================================
"""runtime."""

from .builder import ContextBuilder
from .history import HistoryQueryService
from .models import ContextBuildRequest, ContextItem, ContextSnapshot, DecisionContext
from .repository import ContextRepository

__all__ = [
    "ContextBuilder", "HistoryQueryService", "ContextBuildRequest", "ContextItem",
    "ContextSnapshot", "DecisionContext", "ContextRepository",
]
