# =============================================================================
# 【维护注释】文件：terminal_access/repeater/settings/__init__.py
# 所属层次：网关配置层
# 主要职责：负责 gateway.ini 与环境配置的解析、校验和只读配置模型。
# 项目内直接依赖：.loader, .model, .parsing
# 主要公开符号：无；以导入副作用、常量、数据模型或包导出为主
# 兼容性：不得改变既有外部 HTTP 路径、protobuf 字段/工具 ID、ADK 调用含义或公开 Python 导入路径。
# 修改原则：业务校验留在服务端；模型只做语义选择/填参；跨层通信使用明确契约，避免隐式全局状态。
# 排障顺序：先看输入契约与日志，再看本层返回值，最后沿项目内直接依赖追踪到下游；不要跨层临时绕过校验。
# =============================================================================
"""类型化网关配置公共接口。"""

from .loader import load_config
from .model import (
    AUXILIARY_INI_ONLY_PORT_KEYS,
    CORE_PORT_KEYS,
    PORT_KEYS,
    GatewayConfig,
)
from .parsing import ConfigError

__all__ = [
    "AUXILIARY_INI_ONLY_PORT_KEYS",
    "CORE_PORT_KEYS",
    "PORT_KEYS",
    "ConfigError",
    "GatewayConfig",
    "load_config",
]
